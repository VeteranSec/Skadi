import komand
from .schema import TimesketchCreateuserInput, TimesketchCreateuserOutput
# Custom imports below


class TimesketchCreateuser(komand.Action):

    def __init__(self):
        super(self.__class__, self).__init__(
                name='timesketch_createuser',
                description='Create a TimeSketch user with the base64 encoded username and  password provided',
                input=TimesketchCreateuserInput(),
                output=TimesketchCreateuserOutput())

    def run(self, params={}):
        # TODO: Implement run function
        return {}

    def test(self):
        # TODO: Implement test function
        return {}
