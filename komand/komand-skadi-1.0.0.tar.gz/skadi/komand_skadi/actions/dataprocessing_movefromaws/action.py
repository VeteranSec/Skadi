import komand
from .schema import DataprocessingMovefromawsInput, DataprocessingMovefromawsOutput
# Custom imports below


class DataprocessingMovefromaws(komand.Action):

    def __init__(self):
        super(self.__class__, self).__init__(
                name='dataprocessing_movefromaws',
                description='Transfers data between AWS and local mounted partitions',
                input=DataprocessingMovefromawsInput(),
                output=DataprocessingMovefromawsOutput())

    def run(self, params={}):
        # TODO: Implement run function
        return {}

    def test(self):
        # TODO: Implement test function
        return {}
