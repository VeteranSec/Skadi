import komand
from .schema import TimesketchDeleteuserInput, TimesketchDeleteuserOutput
# Custom imports below


class TimesketchDeleteuser(komand.Action):

    def __init__(self):
        super(self.__class__, self).__init__(
                name='timesketch_deleteuser',
                description='Delete the Base64 encoded timesketch name provided',
                input=TimesketchDeleteuserInput(),
                output=TimesketchDeleteuserOutput())

    def run(self, params={}):
        # TODO: Implement run function
        return {}

    def test(self):
        # TODO: Implement test function
        return {}
